%%
%Alfredo Zhu Chen
%Andrés Islas Bravo
%Luis Arturo Dan Fong
%Juan Pablo Valverde López
%%%%%%%%%%%%Modelos utilizando Pr(d0)%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Clear environment
clc
clear all
close all
%% Read data
dbm=xlsread('Cocina.xlsx',3,'L24:S31');

%%  Provide a dBm received power 3D map (surface) detected, use interpolation to generate received power at more points than those measured. 
[X,Y]=meshgrid(2:0.5:5.5,-4:0.5:-0.5);   %Coordinates
[XInt,YInt]=meshgrid(2:0.1:5.5,-4:0.1:-0.5); %Coordinates interpolated
mapInt = griddata(X,Y,dbm,XInt,YInt,'cubic');
figure
surface(mapInt); %Interpolated 3D map
    xticks(0:5:75)
    xticklabels(2:0.5:5.5)
    yticks(0:5:45)
    yticklabels(-4:0.5:-0.5)
    xlim([1 36])
    ylim([1 36])
    colorbar
    title('Propagation of WiFi Signal in Kitchen','Interpreter','latex','FontSize',15,'FontWeight','bold','Color','k')
    xlabel('Distancia $[m]$','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
    ylabel('Distancia $[m]$','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
    zlabel('Potencia Recibida $[dBm]$','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
%% For the antenna, with your data obtained, provide a 2D plot of distance in meters vs. power received in dBm. Consider the average of dBms when you have several measurements at the same distances. This plot is distance dependent, not location dependent.
%********Adaptar la ecuación a la posición del modem********************
D=sqrt((X).^2+(Y).^2); %Distancias euclidianas
sigma=std(dbm(:)); %Desviación estándard de las potencias recibidas
%dbm(dbm==0)=inf; %poner la potencia en donde se encuentra la antena en infinito
dc=(D(end:-1:1)).'; %pasar las distancias euclidianas a un vector columna
dbmc=(dbm(end:-1:1)).'; %pasar las potencias recibidas en un vector columna
[dcSorted,I] =sort(dc); %Ordenar las distancias 
dbmcSorted = dbmc(I); %ordenar las potencias recibidas
d_and_dbm=[dcSorted(:) dbmcSorted(:)]; %concatenación de las distancias euclidianas con potencias recibidas
d_and_dbm=d_and_dbm(d_and_dbm(:,2)>-100,:); %Quitar potencias iguales a 100 para no considerarlas en el linear regression
d=d_and_dbm(:,1); %distancias
dbmc=d_and_dbm(:,2); %potencias recibidas
d_log=log10(d);  %pasar a log10 las distancias
count=0; %Contador de distancias repetidas
prom=[]; %promedios
d_and_dbm_meanD=[]; %promediar potencias que tienen distancias iguales
for i=2:size(d_and_dbm,1) %Iterar todos los datos empezando por el segundo
    if d_and_dbm(i,1)==d_and_dbm(i-1,1) %Checar si la distancia actual es igual a la previa
        count=count+1; %Acumular si hay distancia repetida 
    else
        for j=i-1:-1:i-count-1 %Iterar con las distancias que se repiten
            prom=[prom d_and_dbm(j,2)]; %guardar(concatenar) potencias con mismas distancias
        end
        prom=mean(prom); %obtener el promedio de las potencias con las mismas distancias
        d_and_dbm_meanD=[d_and_dbm_meanD;[d_and_dbm(i-1,1),prom]]; %Concatenar la distancia y el promedio con matriz
        prom=[]; 
        count=0; %Resetear contador de distancias repetidas
    end
end
    figure
    semilogx(d_and_dbm_meanD(:,1),d_and_dbm_meanD(:,2),'*b')%plot de datos, las potencias se promedian si tienen distancias iguales
    xlabel('Distance $d$ [m]','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
    ylabel('$P_{R}[dBm]$','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
    title('Averaged Distances $[m]$ vs. Power Received $[dBm]$','Interpreter','latex','FontSize',15,'FontWeight','bold','Color','k')
    grid
%% Use the free-space Friis model to estimate power received and path loss and plot them as a function of distance.
% Free space
d0=1;
PR_d0=-30.7692; %in dBm
n_free=2;
PR_dbm_free=PR_d0+10*n_free*log10(d0./d);

%%  2-ray model
n_2R=4;
PR_dbm_2R=PR_d0+10*n_2R*log10(d0./d);

%% Linear regression with polynomial of order 1 
% polyfit(logarithmic distances,dbm,order) the result is the set of coefficients of polynomial are given in order starting with that for the highest power of x
coeficientes=polyfit(d_log,dbmc,1); 
% Evaluate polynomial with coefficients just obtained at logarithmic distances d_log. This will be the line in the plot for the linear regression
PR_dbm_LR1=polyval(coeficientes,d_log);
% take first coefficient (slope of line) and divide by 10 to get PLE
ple=abs(coeficientes(1,1))/10;
    %ple with Pr(d0) model
PR_dbm_LR2=PR_d0+10*ple*log10(d0./d);

%% Now estimate the path loss exponent using the statistical method of maximum likelihood (ML)
%Simple Model
n_ML=sum(PR_d0*log10(d)-log10(d).*dbmc)./sum((10*((log10(d)).^2))); %exponente del modelo simple 
PR_dbm_simple=PR_d0+10*n_ML*log10(d0./d); %Potencias recibidas con modelo simple
figure %figura3
    %semilogx(d,dbmc,'*r',d,PR_dbm_LR1,'b',d,PR_dbm_LR2,'g',d,PR_dbm_2R,'c',d,PR_dbm_free,'m',d,PR_dbm_simple,'y');
    semilogx(d,dbmc,'*r',d,PR_dbm_LR1,'b',d,PR_dbm_LR2,'g',d,PR_dbm_2R,'c',d,PR_dbm_free,'m');
    xlabel('Distance $d$ [m]','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
    ylabel('$P_{R} [dBm]$','Interpreter','latex','FontSize',12,'FontWeight','bold','Color','k')
    title('Propagation Models - Kitchen','Interpreter','latex','FontSize',15,'FontWeight','bold','Color','k')
    %legend('Data','Linear Regression','Exponent Linear Regression in Deterministic Model','2-Ray Model','Free Space Model','MMSE');
    legend('Data','Linear Regression','Exponent Linear Regression in Deterministic Model','2-Ray Model','Free Space Model');
%% Squared error for all models
n_all=[ple,ple,n_2R,n_free,n_ML]; %exponentes: regresión lineal, 2 rayos, espacio libre, simple
sq_errorLR1     = mean((dbmc-polyval(coeficientes,d_log)).^2);
sq_errorLR2     = mean((dbmc-PR_d0+10*n_all(2)*log10(d)).^2);
sq_error2R      = mean((dbmc-PR_d0+10*n_all(3)*log10(d)).^2);
sq_errorFree    = mean((dbmc-PR_d0+10*n_all(4)*log10(d)).^2);
sq_errorML      = mean((dbmc-PR_d0+10*n_all(5)*log10(d)).^2);
sq_errors=[sq_errorLR1,sq_errorLR2,sq_error2R,sq_errorFree,sq_errorML];
%errors=sqrt(sq_errors);
[errormin,minError_idx]=min(sq_errors); %obtener el error menor y el índice
n_best=n_all(minError_idx); %exponente para el modelo con menor error

%% Estimate the sigma of the environment using statistical method ML
sigmaML   = sqrt(sum((dbmc-PR_d0+10*n_ML*log10(d)).^2)/size(d,1));
sigma2R   = std(PR_dbm_2R);
sigmaLR1  = std(PR_dbm_LR1);
sigmaLR2  = std(PR_dbm_LR2);
sigmaFree = std(PR_dbm_free);
%% Estimate the standard deviation of your data by using statistical tools (averages)
sigmaMeds = std(dbmc);
sigma_all=[sigmaLR1,sigmaLR2,sigma2R,sigmaFree,sigmaML];
sigma_best=sigma_all(minError_idx); 
